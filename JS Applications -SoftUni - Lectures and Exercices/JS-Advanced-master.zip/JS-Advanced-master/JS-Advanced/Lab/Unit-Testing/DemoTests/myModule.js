function sum(a, b){
    return a + b + 1;
}

module.exports = sum;