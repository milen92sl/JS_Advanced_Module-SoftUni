function echo (input){
    console.log(input.length);
    console.log(input);
}

echo('Hello, JavaScript!');
