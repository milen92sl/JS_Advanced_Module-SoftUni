function squareOfStars (size){
    
    for(let i = 0; i < size; i++){
        console.log(('* ').repeat(size));
    }
}

squareOfStars(2);