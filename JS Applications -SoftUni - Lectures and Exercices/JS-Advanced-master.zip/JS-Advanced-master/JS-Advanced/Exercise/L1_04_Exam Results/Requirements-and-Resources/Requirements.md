﻿# 04 - Exam Result
------
Problems for the [“HTML and CSS”](#) course @ **SoftUni**

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/#!/List/ByCategory/165/HTML-and-CSS)

## Constraints
* Change the title
* Use **table**, **thead**, **tbody** and **tfoot** tags
* Use a **colspan** attribute where is needed