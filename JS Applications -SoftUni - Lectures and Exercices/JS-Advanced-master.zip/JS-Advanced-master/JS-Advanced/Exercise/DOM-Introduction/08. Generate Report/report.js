function generateReport() {
    //TODO
}