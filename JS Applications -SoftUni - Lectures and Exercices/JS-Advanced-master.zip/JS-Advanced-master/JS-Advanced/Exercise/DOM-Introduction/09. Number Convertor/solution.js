function solve() {

    //TODO...
}