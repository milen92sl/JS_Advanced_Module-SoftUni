function printArray(arr, delimiter){
    console.log(arr.join(delimiter));
}

printArray(['How about no?', 
'I',
'will', 
'not', 
'do', 
'it!'], 
'_'
)