function attachEventsListeners() {
    console.log('TODO:...');
}