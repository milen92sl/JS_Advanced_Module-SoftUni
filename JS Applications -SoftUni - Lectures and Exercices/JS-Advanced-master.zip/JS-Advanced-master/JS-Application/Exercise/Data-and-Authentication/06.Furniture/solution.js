function solve() {

  //TODO...
}